## running get_datasets.py 

python get_datasets.py